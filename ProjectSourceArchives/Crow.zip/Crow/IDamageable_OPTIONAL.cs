// =====================================================================
// IDamageable_OPTIONAL.cs
// Skip this file if IDamageable already exists in the project.
// Provided only so CrowEnemy.cs and CrowProjectile.cs compile in a repo
// that does not yet have the interface. Delete it if your project already
// declares IDamageable with the same signature.
// =====================================================================

using UnityEngine;

public interface IDamageable
{
    void TakeDamage(int amount, Vector2 hitDirection);
}
